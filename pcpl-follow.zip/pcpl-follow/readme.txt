=== Lets Users Follow you on social media ===
Contributors: dhananjay22a
Tags: Lets Users Follow you on social media
Requires at least: 5.5
Tested up to: 6.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A WordPress plugin to allow the administrators of site to add a block at bottom of their posts where visitors would be asked to follow their social media page if they wish.

== Description ==

Follow Us on Social Media is a plugin to show a block/box with message at bottom of every posts. It asks visitors to follow the site's social media pages if they wish.

= Privacy notices =

This plugin in itself does not:

* track users.
* write any personal data to the database.
* send any data to external servers.
* use cookies.

= What's Next =
If you find this plugin useful, please leave a good rating.
You can also provide us [feedback here](http://siwanpress.com/provide-feedback/);


= Credits =

This plugin is created by [Dhananjay Singh](https://siwanpress.com).

== Installation ==
1. Extract `pcpl-follow.zip` to your `/wp-content/plugins/` directory.
2. In the admin panel under plugins activate the plugin - Follow Us on Social Media

If you need any further help, please contact our [support desk](http://siwanpress.com/support/ "Support").


== Screenshots ==

1. PCPL Follow Us on Social Media menu
2. PCPL Follow Us on Social Media configure content
3. PCPL Follow Us on Social Media enable/disable plugin
4. PCPL Follow Us on Social Media about
5. PCPL Follow Us on Social Media frontend
